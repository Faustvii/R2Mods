# Quality of life chests

- Every player in the game gets a lunar coin when one is picked up, even if they're dead.
- Technically only needed by the host.

For feature suggestions or bug reports go [here](https://github.com/Faustvii/R2Mods/issues)

## Changelog

**1.0.0**

* Release of QoL chests.

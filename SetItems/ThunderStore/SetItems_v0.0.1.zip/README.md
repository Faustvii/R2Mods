# Set Items

- Adds the fire god set
- Not balanced at all

For feature suggestions or bug reports go [here](https://github.com/Faustvii/R2Mods/issues)

## Changelog

**0.0.1**

* Release of Set Items.